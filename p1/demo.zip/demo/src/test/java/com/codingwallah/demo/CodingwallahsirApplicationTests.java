package com.codingwallah.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingwallahsirApplicationTests {

	@Test
	void contextLoads() {
	}

}
