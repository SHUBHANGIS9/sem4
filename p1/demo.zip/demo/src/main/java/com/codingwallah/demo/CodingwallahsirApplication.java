package com.codingwallah.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodingwallahsirApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodingwallahsirApplication.class, args);
	}

}
